import {test} from '@playwright/test'
test('first playwright test', async({page})=>
{

// const context=await browser.newContext();
// const page=await context.newPage();

await page.goto("https://www.google.com");
console.log(await page.title())  ;

});


test.only('second playwright test', async({page})=>
{

await page.goto("https://demo.automationtesting.in/Register.html");
console.log(await page.title())  ;
const firstname=await page.locator("[placeholder='First Name']")
await firstname.fill("Saurabh")
await page.waitForTimeout(5000);
await firstname.clear();
//await page.pause();
await page.waitForTimeout(5000);





});

