import {test,expect} from '@playwright/test'

test('7thTest', async({page})=>
{
await page.goto("https://www.techlistic.com/p/selenium-practice-form.html");
const multiselect=await page.locator("[id='selenium_commands']");
if(multiselect.isVisible==true)
{
    await multiselect.selectOption({index:1},'Navigation Commands');
}
await page.pause();



});

test('8th Test', async({page})=>
{
await page.goto("https://demoqa.com/buttons");
const dblbutton =await page.locator("[id='doubleClickBtn']");
await dblbutton.dblclick();
await page.pause();





});


test.only('9th Test', async({page})=>
{
// await page.goto("https://the-internet.herokuapp.com/drag_and_drop");
// const source=await page.locator("[id='column-a']");
// const target=await page.locator("[id='column-b']");

// await source.dragTo(target);

// await page.pause();

await page.goto('https://www.amazon.in/');
  await page.getByRole('link', { name: 'Refrigerators' }).click();
  await page.getByRole('link', { name: 'Sponsored Ad - Haier 602L' }).click();
  await page.getByRole('button', { name: 'Add to Cart', exact: true }).click();
  await page.getByRole('button', { name: 'Proceed to Buy (2 items) Buy' }).click();





});


