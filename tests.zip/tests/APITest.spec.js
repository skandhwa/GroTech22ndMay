import {test,request} from '@playwright/test'
test('API Test', async () => {
  const apiContext = await request.newContext();
  const authToken = "a682a89b74963538f47d3ec72b6af8f655ef7c20f8d1a7e3ad8582ffd8dfdf64";

  const response = await apiContext.post('https://gorest.co.in/public/v2/users', {
    headers: {
      'Content-Type': 'application/json',
      'Authorization': `Bearer ${authToken}`,
    },
    data: {
      name: 'Harry',
      gender: 'male',
      email: 'werewjuj@gmail.com',
      status: 'active'
    }
  });

  const responseBody = await response.json();
  console.log('Status:', response.status());
  console.log('Response Body:', responseBody);
});