import {test} from '@playwright/test'
test('Window Handling', async({browser})=>
{

const context=await browser.newContext();
const page=await context.newPage();

await page.goto("https://demo.automationtesting.in/Windows.html");
console.log(await page.title())  ;
const doclink=await page.locator("(//button[@class='btn btn-info'])[1]");

const[newPage]=  await Promise.all([context.waitForEvent('page'),doclink.click()]);
await newPage.waitForLoadState();

console.log(await newPage.title());





});


test.only('Frame Handling', async({page})=>
{

await page.goto("https://demo.automationtesting.in/Frames.html");
 const frameLocator = page.frameLocator("#singleframe");
await frameLocator.locator("(//input[@type='text'])[1]").fill("Saurabh");





});