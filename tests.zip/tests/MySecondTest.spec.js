import {test,expect} from '@playwright/test'

test('third playwright test', async({page})=>
{
await page.goto("https://www.facebook.com/");
await expect(page).toHaveTitle("Facebook – log in or sign up");
await page.pause();
});


test('fourth playwright test', async({page})=>
{
await page.goto("https://demo.automationtesting.in/Register.html");
const heading=page.locator("//h2");
const expectecdcontent=await heading.textContent();
expect(expectecdcontent).toContain("Register");


});

test('fifth playwright test', async({page})=>
{
await page.goto("https://demo.automationtesting.in/Register.html");
const rdbtn= await page.locator("[value='Male']");

await rdbtn.click();
await page.pause();


});

test('sixth playwright test', async({page})=>
{
await page.goto("https://demo.automationtesting.in/Register.html");
const drpdown= await page.locator("[id='Skills']");


//await drpdown.selectOption({index:2});
//await drpdown.selectOption({label:"Analytics"});

await drpdown.selectOption('Android');


await page.pause();





});